<?php

namespace Corals\Foundation\Exceptions;

use Exception;

/**
 * Base class for exceptions in Laravel Breadcrumbs.
 */
abstract class BreadcrumbsException extends Exception
{
}
