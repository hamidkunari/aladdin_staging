<?php

namespace Corals\Foundation\Traits\Cache;

trait Cachable
{
    use PivotEventTrait, Caching, ModelCaching;
}
