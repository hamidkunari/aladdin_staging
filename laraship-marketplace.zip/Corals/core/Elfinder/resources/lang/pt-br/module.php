<?php

return [

    'elfinder' => [
        'title' => 'Gerenciador de arquivos',
    ],


];