<?php

return [

    'menu' => [
        'title' => 'Menus',
        'title_singular' => 'Cardápio',
    ],


];