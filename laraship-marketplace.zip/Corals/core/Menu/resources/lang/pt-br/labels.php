<?php

return [

    'root_menu_title' => 'Menu Raiz [:title]',
    'parent_menu_title' => '[:title] Sub Item de menu',
    'menu_item_title' => 'Item de menu [:title]',
    'create_sub' => 'Criar Sub',


];