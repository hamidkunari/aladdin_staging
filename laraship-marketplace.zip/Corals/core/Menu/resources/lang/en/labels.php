<?php

return [
    'root_menu_title' => 'Root Menu [:title]',
    'parent_menu_title' => '[:title] Sub Menu Item',
    'menu_item_title' => 'Menu Item [:title]',
    'create_sub' => 'Create Sub',
    'toggle_status' => 'Toggle Status'
];