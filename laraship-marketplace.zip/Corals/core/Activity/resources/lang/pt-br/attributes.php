<?php

return [

    'activity' => [
        'log_name' => 'Registro',
        'subject_type' => 'Modelo',
        'subject_id' => 'ID do modelo',
        'causer_id' => 'Do utilizador',
        'description' => 'Descrição',
        'properties' => 'Propriedades',
    ],


];