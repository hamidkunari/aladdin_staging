<?php


return [
    'activity' => [
        'log_name' => 'Log',
        'subject_type' => 'Model',
        'subject_id' => 'Model Id',
        'causer_id' => 'User',
        'description' => 'Description',
        'properties' => 'Properties',
    ],
];