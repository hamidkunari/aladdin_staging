<?php

return [

    'custom_field' => [
        'title' => 'Os campos personalizados',
        'title_singular' => 'Campo customizado',
    ],
    'module' => [
        'title' => 'Módulos',
        'title_singular' => 'Módulo',
    ],
    'setting' => [
        'title' => 'Configurações',
        'title_singular' => 'Configuração',
    ],
    'cache' => [
        'title' => 'Gerenciamento de Cache',
    ],


];