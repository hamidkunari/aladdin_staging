<?php


return [

    'custom_field' => [
        'title' => 'Custom Fields',
        'title_singular' => 'Custom Field',
    ],
    'module' => [
        'title' => 'Modules',
        'title_singular' => 'Module',

    ],
    'setting' => [
        'title' => 'Settings',
        'title_singular' => 'Setting',
    ],
    'cache' => [
        'title' => 'Cache Management',
    ]

];