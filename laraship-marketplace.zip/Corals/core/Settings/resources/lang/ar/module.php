<?php


return [

    'custom_field' => [
        'title' => 'الحقول المخصصة',
        'title_singular' => 'حقل مخصص',
    ],
    'module' => [
        'title' => 'النماذج',
        'title_singular' => 'نموذج',

    ],
    'setting' => [
        'title' => 'الاعدادات',
        'title_singular' => 'الاعدادات',
    ],
    'cache' => [
        'title' => 'ادارة ذاكرة التخزين المؤقت',


    ]

];