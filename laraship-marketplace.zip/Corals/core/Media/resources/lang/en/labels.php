<?php

return [
    'media' => [
        'attachment' => [
            'description' => 'Description',
            'attachments' => 'Attachments',
            'attachment' => 'Attachment',
            'click_to_add_new_row' => 'click to add new attachement.',
            'add_new_attachments' => 'Add Attachments',
            'no_files_attached' => 'No Files Attached',
            'add_attachments' => 'Add Attachments'
        ]
    ]
];
