<?php

if(isset($_POST)){

	//echo $_POST;

	    $row=0;

		$items_v_no=0;

        $v_items[$items_v_no]['weight']=0;
                    
        $v_items[$items_v_no]['pick_code']=$_POST['vzip'];
        $v_items[$items_v_no]['pick_state']=$_POST['vstate'];
        $v_items[$items_v_no]['pick_country']=$_POST['vcountry'];
        $v_items[$items_v_no]['send_code']=$_POST['czip'];
        $v_items[$items_v_no]['send_state']=$_POST['cstate'];
        $v_items[$items_v_no]['send_country']=$_POST['ccountry'];
        $v_items[$items_v_no]['weight']=$_POST['weight'];
        $v_items[$items_v_no]['width']=$_POST['width'];
        $v_items[$items_v_no]['length']=$_POST['length'];
        $v_items[$items_v_no]['height']=$_POST['height'];

                    //print_r($v_items);
    
        $domain = "https://connect.easyparcel.my/?ac=";

        $action = "EPRateCheckingBulk";
        $postparam = array(
        'api'   => 'EP-fFhjYfd0c',
        'bulk'  => $v_items,
            'exclude_fields'    => array(
                'rates.*.pickup_point',
            )
        );

        //print_r($postparam);

        $url = $domain.$action;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postparam));
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

        if(curl_errno($ch)){
		    echo 'Curl error: ' . curl_error($ch);
		}

        ob_start(); 
        $return = curl_exec($ch);
        ob_end_clean();
        //echo curl_errno($ch);
		//echo curl_error($ch);
        curl_close($ch);
        
        $json = json_decode($return,true);

        //echo $return;   

        // if($row==0){
        //print_r($json);
        //   echo '<br><br>';
        // }

        $results=$json['result'];
        
        echo '<table class="shipping-ep">
        
        <tr>
            <th></th>
            <th>Logo</th>
            <th>Name</th>
            <th>Service ID</th>
            <th>Price</th>
        </tr>
        
        ';
        foreach ($results as $result => $result_data) {
            for ($rno=0; $rno < count($result_data['rates']); $rno++) {

                if(count($result_data['rates'][$rno]['dropoff_point'])>0){
                    
                    echo '
                    <tr>
                        <td><input type="radio" name="ep-ship" value="'.$result_data['rates'][$rno]['service_name'].'"></td>
                        <td><img src="'.$result_data['rates'][$rno]['courier_logo'].'" width="100px"></td>
                        <td>Service Name : '.$result_data['rates'][$rno]['service_name'].'</td>
                        <td>Service ID:'.$result_data['rates'][$rno]['service_id'].'</td>
                        <td>Price : RM '.$result_data['rates'][$rno]['price'].'</td>
                    </tr>
                    
                    
                    ';
                    
                    //echo 'Service Name : '.$result_data['rates'][$rno]['service_name'].'<br>Service ID:'.$result_data['rates'][$rno]['service_id'].'<hr>';
                    
                }
            }
        }
        
        echo '</table>';
}else{
	echo 'no data';
}

?>